#!/bin/bash

echo "Running test script....yay!"
